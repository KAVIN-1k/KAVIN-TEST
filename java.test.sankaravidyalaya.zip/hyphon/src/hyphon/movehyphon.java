package hyphon;

public class movehyphon {
	
		static String movehyphon(String str)
		{
			if(str==null)
				return null;
				char[] ch=str.toCharArray();
				String hyphen="";
				for (int i =0;i < ch.length; i++)
				{
					if(ch[i]=='-')
						hyphen+="-";
				}
				str=str.replace("-","");
				return hyphen+str;
		}

	public static void main(String[] args) {
		System.out.println(movehyphon("kav--ramjjvdfvfvks-----kdfdf"));

	}

}
